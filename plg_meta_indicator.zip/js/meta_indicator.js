document.addEventListener('DOMContentLoaded', () => {

    function numberOfSymbols(e) {
        let el = e.target,
            id = el.id,
            n = el.value.length;

        let targetCharts, min, title;

        if (id == 'jform_title') {
            targetCharts = paramsMetaIndicator.maxTitle;
            min = paramsMetaIndicator.minTitle;
            title = paramsMetaIndicator.txtTitle + ' ';
        }
        else if (id == 'jform_metadesc' || id == 'jform_params_menu_meta_description' || id == 'jform_MetaDesc') {
            targetCharts = paramsMetaIndicator.maxDesc;
            min = paramsMetaIndicator.minDesc;
            title = paramsMetaIndicator.txtMeta + ' ';
        }


        let label = document.querySelector('#' + id + '-lbl');
        label.textContent = title + n;


        let color, width;

        if (n < min) {
            color = 'red';
            width = n * 100 / targetCharts;
        }
        else if (n >= min && n <= targetCharts) {
            color = 'green';
            width = n * 100 / targetCharts;
        }
        else if (n > targetCharts) {
            color = 'orange';
            width = 100;
        }

        let indicatorPlaceholder = document.querySelector('.' + id + '_indicator__placeholder');

        indicatorPlaceholder.style.width = width + '%';
        indicatorPlaceholder.style.background = color;
    };

    let indicators = ['jform_title', 'jform_metadesc', 'jform_params_menu_meta_description', 'jform_MetaDesc'];

    for (let i = 0; i < indicators.length; i++) {
        const inputItem = document.querySelector('#' + indicators[i]);

        if (inputItem) {
            if (!(indicators[i] == 'jform_title' && paramsMetaIndicator.title == 0)) {
                let indicatorHTML = document.createElement('div');
                indicatorHTML.className = indicators[i] + '_indicator';
                indicatorHTML.innerHTML = `<div class="${indicators[i]}_indicator__placeholder"></div>`;

                document.querySelector('#' + indicators[i] + '-lbl').parentNode.appendChild(indicatorHTML);

                inputItem.addEventListener('input', numberOfSymbols);

                let event = new Event('input');
                inputItem.dispatchEvent(event);
            }
        }
    }
});
