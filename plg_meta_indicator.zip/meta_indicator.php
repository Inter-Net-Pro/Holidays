<?php
/**
 * @package		Joomla.Plugin
 * @subpackage	System.meta_indicator
 * 
 * @copyright	Copyright (C) Inter-Net Pro. All right reserved
 * @license     GNU General Public License version 2 or later
 */

if (!defined('_JEXEC')) die('Direct Access to ' . basename(__FILE__) . ' is not allowed.');

class plgSystemMeta_Indicator extends JPlugin
{

	protected $autoloadLanguage = true;

	function __construct($event, $params)
	{
		parent::__construct($event, $params);
	}

	function onBeforeRender()
	{

		if ( !JFactory::getApplication()->isAdmin() || JFactory::getDocument()->getType() !== 'html' )
		{
			return;
		}
		
		$app		= JFactory::getApplication();
		$option		= $app->input->get('option');
		$layout		= $app->input->get('layout');
		$view		= $app->input->get('view');
		$txtTitle	= JText::_('PLG_META_INDICATOR_TXT_TITLE');
		$txtMeta	= JText::_('PLG_META_INDICATOR_TXT_METADESCRIPTION');

		if ( $option !== 'com_content' && $option !== 'com_categories' && $option !== 'com_menus' && $option !== 'com_config' )
		{
			return;
		}

		$com_edit = array('com_content', 'com_categories', 'com_menus');

		foreach ($com_edit as &$com_id)
		{
			if ($option == $com_id && $layout !== 'edit')
			{
				return;
			}
		}

		switch ( $view ) {
			case 'article':	
				$title		= $this->params[titleArticle];
				$minTitle	= $this->params[minTitleArticle];
				$maxTitle	= $this->params[maxTitleArticle];
				break;
			case 'category':
				$title		= $this->params[titleCategory];
				$minTitle	= $this->params[minTitleCategory];
				$maxTitle	= $this->params[maxTitleCategory];
				break;
			case 'item':
				$title		= $this->params[titleMenu];
				$minTitle	= $this->params[minTitleMenu];
				$maxTitle	= $this->params[maxTitleMenu];
				break;
		}

		if ($option == 'com_config')
		{
			$title		= 0;
			$minTitle	= 0;
			$maxTitle	= 0;
			$txtMeta = JText::_('PLG_META_INDICATOR_TXT_METADESCRIPTION_SITE');;
		}

		$doc = JFactory::getDocument();

		$doc->addStyleSheet('/plugins/system/meta_indicator/css/meta_indicator.css');

		$doc->addScriptDeclaration('
			const paramsMetaIndicator = {
				minDesc: ' . $this->params[minMetaDescription] . ',
				maxDesc: ' . $this->params[maxMetaDescription] . ',
				title: ' . $title . ',
				minTitle: ' . $minTitle . ',
				maxTitle: ' . $maxTitle . ',
				txtTitle: "' . $txtTitle . '",
				txtMeta: "' . $txtMeta . '"
			};
		');
		
		$doc->addScript('/plugins/system/meta_indicator/js/meta_indicator.js');
	}
}
