<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_holidays
 * 
 * @copyright	Copyright (C) Inter-Net Pro. All right reserved
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die();

require(JModuleHelper::getLayoutPath('mod_holidays', $params->get('layout', 'default')));
require_once dirname(__FILE__).'/helper.php';


$type = $params->get('type', 'none');

if ( $type == 'garland' )
{
    $list = modHolidaysHelper::getList($params);
}
elseif ( $type == 'halloween' )
{
    $doc = JFactory::getDocument();
    
    $doc->addScript('https://code.jquery.com/jquery-3.3.1.slim.min.js');
    $doc->addScript('/modules/mod_holidays/assets/js/halloween-bats.js');
}


$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));