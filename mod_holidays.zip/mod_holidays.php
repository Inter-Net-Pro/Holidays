<?php
defined('_JEXEC') or die();

require(JModuleHelper::getLayoutPath('mod_holidays', $params->get('layout', 'default')));
require_once dirname(__FILE__).'/helper.php';


$type = $params->get('type', 'none');

if ( $type == 'garland' )
{
    $list = modHolidaysHelper::getList($params);
}


$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));