<?php

defined('_JEXEC') or die();

$snowShow = $params->get('snowShow', '0');

if ($snowShow == '1') {
    
    $snowType   = $params->get('snowType', 'css');
    $doc        = JFactory::getDocument();

    if($snowType == 'js') {
        $flakesMax			= (int) $params->get('flakesMax', '128');
        $flakesMaxActive	= (int) $params->get('flakesMaxActive', '64');
        $animationInterval	= (int) $params->get('animationInterval', '33');
        $followMouse		= $params->get('followMouse', '0') ? 'true' : 'false';
        $snowColor			= $params->get('snowColor', '#fff');
        $snowCharacter		= $params->get('snowCharacter', '&bull;');
        $snowStick			= $params->get('snowStick', '1') ? 'true' : 'false';

        $js	= "
            sl_snowfalling.flakesMax			= $flakesMax;
            sl_snowfalling.flakesMaxActive		= $flakesMaxActive;
            sl_snowfalling.animationInterval	= $animationInterval;
            sl_snowfalling.followMouse			= $followMouse;
            sl_snowfalling.snowColor			= '$snowColor';
            sl_snowfalling.snowCharacter		= '$snowCharacter';
            sl_snowfalling.snowStick			= $snowStick;
            sl_snowfalling.zIndex				= 9999;
        ";

        $doc->addScript(JURI::base() . 'modules/mod_holidays/assets/js/snow.js');
        $doc->addScriptDeclaration($js);
    }
    elseif ($snowType == 'css') {
        $color = $params->get('snowCssColor') == 'blue' ? '_blue' : '';

        $doc->addStyleDeclaration("
            body {
                background-image: url('modules/mod_holidays/media/img/snow/snow$color.png'), url('modules/mod_holidays/media/img/snow/snow3$color.png'), url('modules/mod_holidays/media/img/snow/snow2$color.png');
                -webkit-animation: snow 20s linear infinite;
                -moz-animation: snow 20s linear infinite;
                -ms-animation: snow 20s linear infinite;
                animation: snow 20s linear infinite;
            }

            @keyframes snow {
                0% {background-position: 0px 0px, 0px 0px, 0px 0px;}
                100% {background-position: 500px 1000px, 400px 400px, 300px 300px;}
            }

            @-moz-keyframes snow {
                0% {background-position: 0px 0px, 0px 0px, 0px 0px;}
                100% {background-position: 500px 1000px, 400px 400px, 300px 300px;}
            }

            @-webkit-keyframes snow {
                0% {background-position: 0px 0px, 0px 0px, 0px 0px;}
                50% {background-color:#b4cfe0;}
                100% {background-position: 500px 1000px, 400px 400px, 300px 300px; background-color:#6b92b9;}
            }

            @-ms-keyframes snow {
                0% {background-position: 0px 0px, 0px 0px, 0px 0px;}
                100% {background-position: 500px 1000px, 400px 400px, 300px 300px;}
            }
        ");
            
    }
}


?>