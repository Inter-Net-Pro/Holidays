<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_holidays
 * 
 * @copyright	Copyright (C) Inter-Net Pro. All right reserved
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

$typeModule 	= $params->get('type');
$snowShow		= $params->get('snowShow', '0');
$addSoundKeydown = $params->get('addSoundKeydown', '0');
$addCustomCSS	= $params->get('addCustomCSS', '0');

if ($typeModule == 'garland')
{
	if ($snowShow == '1') {
		$doc        = JFactory::getDocument();

		$flakesMax			= (int) $params->get('flakesMax', '128');
		$flakesMaxActive	= (int) $params->get('flakesMaxActive', '64');
		$animationInterval	= (int) $params->get('animationInterval', '33');
		$followMouse		= $params->get('followMouse', '0') ? 'true' : 'false';
		$snowColor			= $params->get('snowColor', '#fff');
		$snowCharacter		= $params->get('snowCharacter', '&bull;');
		$snowStick			= $params->get('snowStick', '1') ? 'true' : 'false';

		$js	= "
			sl_snowfalling.flakesMax			= $flakesMax;
			sl_snowfalling.flakesMaxActive		= $flakesMaxActive;
			sl_snowfalling.animationInterval	= $animationInterval;
			sl_snowfalling.followMouse			= $followMouse;
			sl_snowfalling.snowColor			= '$snowColor';
			sl_snowfalling.snowCharacter		= '$snowCharacter';
			sl_snowfalling.snowStick			= $snowStick;
			sl_snowfalling.zIndex				= 9999;
		";

		$doc->addScript('/modules/mod_holidays/assets/js/snow.js');
		$doc->addScriptDeclaration($js);
	}

	if ($addSoundKeydown == '1') {
		$sound_key = "var soundKeyGarland = true;";

		$doc->addScriptDeclaration($sound_key);
	}

	if ($addCustomCSS == '1') {
		$customCSS = $params->get('customCSS', '');
		
		$doc = JFactory::getDocument();
		$doc->addStyleDeclaration($customCSS);
	}
}
